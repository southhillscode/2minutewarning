//: Playground - noun: a place where people can play

import UIKit

var minutesInDay = 0
var myPeriodsInDay = 0
var myPeriodLength = 0
var myPassingPeriodLength = 0
var myPassingPeriodInDay = 0
var myBreakLength = 0
var myLunchLength = 0
var currentSchedule: Int?

func getMinutesInDay(periodsInDay:Int, periodLength: Int, passingPeriodLength:Int, passingPeriodInDay:Int, breakLength:Int, lunchLength:Int) -> Int {
    myPeriodsInDay = periodsInDay
    myPeriodLength = periodLength
    myPassingPeriodLength = passingPeriodLength
    myPassingPeriodInDay = passingPeriodInDay
    myBreakLength = breakLength
    myLunchLength = lunchLength
    minutesInDay = ((myPeriodsInDay * myPeriodLength) - (myPassingPeriodInDay * myPassingPeriodLength) - myBreakLength - myLunchLength)
    return minutesInDay
}

func makeMyLateStartSchedule(startTime: String, lunchAfter: Int) -> String {
    let mySchedule = "Start time is \(startTime) and lunch is after \(lunchAfter)"
    return mySchedule
}

private enum Schedules {
    case eight((String, Int) -> String)
    case nine(Int)
    case ten(Int)
}


private var schedule: Dictionary<String, Schedules> = [
    "Regular"       : Schedules.nine(9),
    "Rally"         : Schedules.ten(10),
    "Late Start"    : Schedules.eight(makeMyLateStartSchedule)
]

func setSchedule(_ mySchedule: String) {
    if let day = schedule[mySchedule]{
        switch day {
        case .eight(let function):
            setMyNotification = CreateNotificationSchedule(startTime: "9:50", function: function)
        case .nine(let value):
            //pass in period length
            let myBreak = value
            print(myBreak)
        case .ten(let value):
            //pass in period length
            let myBreak = value
            print(myBreak)
        }
    }
}

private var setMyNotification: CreateNotificationSchedule

private struct CreateNotificationSchedule {
    let startTime: String
    var function: (String, Int) -> String
    
    func createSchedule(will notifyAt: Int) -> String {
        return function(startTime, notifyAt)
    }
}

setSchedule("Late Start")
//Regular Schedule
var regularScheduleInstructionalMinutes = getMinutesInDay(periodsInDay: 7, periodLength: 51, passingPeriodLength: 5, passingPeriodInDay: 6, breakLength: 10, lunchLength: 35)
//Ralley Schedule is a
var rallyScheduleInstructionalMinutes = getMinutesInDay(periodsInDay: 7, periodLength: 44, passingPeriodLength: 5, passingPeriodInDay: 6, breakLength: 10, lunchLength: 35)
//Extended Lunch
var extendedLunchSchedule = getMinutesInDay(periodsInDay: 7, periodLength: 48, passingPeriodLength: 5, passingPeriodInDay: 6, breakLength: 10, lunchLength: 63)
//Extended Break
var extendedBreakSchedule = getMinutesInDay(periodsInDay: 7, periodLength: 50, passingPeriodLength: 5, passingPeriodInDay: 6, breakLength: 49, lunchLength: 45)
//Minimum Schedule
var minimumSchedule = getMinutesInDay(periodsInDay: 7, periodLength: 30, passingPeriodLength: 5, passingPeriodInDay: 6, breakLength: 10, lunchLength: 0)
// Final Exam Day 1
var finalExamDay1Schedule = getMinutesInDay(periodsInDay: 7, periodLength: 35, passingPeriodLength: 5, passingPeriodInDay: 6, breakLength: 10, lunchLength: 35)

// Late Start
var lateStartSchedule = getMinutesInDay(periodsInDay: 7, periodLength: 34, passingPeriodLength: 5, passingPeriodInDay: 6, breakLength: 10, lunchLength: 39)




